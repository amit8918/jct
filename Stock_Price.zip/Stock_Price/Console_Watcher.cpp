#include "Consol.h"

#include <windows.h>

Consol::Consol(std::string name)
{
    this->name = name;
}

void Consol::Update(string  price)
{
    this->Stock_price = price;
    string display_line = "Price at " + name + " is now " + price;
    wstring Wdisplay_line = std::wstring(display_line.begin(), display_line.end());
    const wchar_t* srcURL = Wdisplay_line.c_str();
    //Lets print on console just to test the working
    MessageBox(NULL, srcURL, L"Console Window", MB_ICONQUESTION);
  
}