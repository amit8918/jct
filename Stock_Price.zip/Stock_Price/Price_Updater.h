#pragma once
#include "Console_Server.h"

class Price_Updater : public Console_Server
{
public:
    void ChangePrice(string price);
};