#include "Price_Updater.h"
#include <algorithm>

using namespace std;


void Price_Updater::ChangePrice(string price)
{
    Notify(price);
}