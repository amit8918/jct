#pragma once
//Header File
#pragma once
#include <vector>
#include <list>
#include "consol.h"

class Console_Server
{
    //Lets keep a track of all the shops we have observing
    std::vector<Consol*> list;

public:
    void Attach(Consol* product);
    void Detach(Consol* product);
    void Notify(string price);
};