#pragma once
#include <iostream>
#include <string>
#include "Console_Watcher.h"

using namespace std;
class Consol : Console_Watcher
{
    //Name of the Console
    std::string name;
    string Stock_price;
public:
    Consol(std::string n);
    void Update(string price);
};