#include "Console_Server.h"
#include <algorithm>

using namespace std;

void Console_Server::Attach(Consol* consolobject)
{
    list.push_back(consolobject);
}
void Console_Server::Detach(Consol* consolobject)
{
    list.erase(std::remove(list.begin(), list.end(), consolobject), list.end());
}

void Console_Server::Notify(string price)
{
    for (vector<Consol*>::const_iterator iter = list.begin(); iter != list.end(); ++iter)
    {
        if (*iter != 0)
        {
            (*iter)->Update(price);
        }
    }
}