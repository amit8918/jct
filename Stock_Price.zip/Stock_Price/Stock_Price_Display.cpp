#include<iostream>
#include <windows.h>
#include <cstdio>
#include <fstream>
#include <string>
#include <ctime>
#pragma comment(lib, "Urlmon.lib")

#include "Price_Updater.h"
#include "Console_Server.h"
#include "consol.h"
using namespace std;


string stock_price_display(const wchar_t*& stock_url, string key, const wchar_t* destFile)
{
	
	time_t now = time(NULL);
	//char *str = ctime(&now);
	char date_time[26] = {};
	ctime_s(date_time, 26, &now);
	// convert now to string form
	if (S_OK == URLDownloadToFile(NULL, stock_url, destFile, 0, NULL))
	{
		cout << date_time << ": File Accessed Successfully\n";
	}
	else
	{
		cout << date_time << ": File Accessed Failed\n";
	}

	string line;
	string stock_price = "";
	ifstream Stockfile(destFile);
	int count = 0;
	//count = pre_calculation()
	if (Stockfile.is_open())
	{
		getline(Stockfile, line);

		int siz = line.size();
		int i = 0;
		int j = 0;
		while (i < siz)
		{
			while ((i < siz) && (line[i] != key[j]))
			{
				i++;
				if (line[i] == ',') { count++; }
			}
			if (line[i] == key[j])
			{
				while ((i < siz) && (j < key.size()) && (line[i] == key[j])) { i++; j++; }
				if (j == key.size()) { i = siz; }
			}
		}
		while (getline(Stockfile, line))
		{
		}

		i = 0;
		int curr = 0;
		while (curr < count)
		{
			if (line[i++] == ',') { curr++; }
		}

		while (line[i] != ',')
		{
			stock_price = stock_price + line[i];
			i++;
		}
		//cout << stock_price << '\n';
		Stockfile.close();
	}
	return stock_price;
}



void Initialize_Dashboard(const wchar_t*& stock_url, string key, const wchar_t* destFile)
{
    Price_Updater Dashboard;

    // Adding Consoles wanting to keep updated stock price
    Consol console1("Console 1");
    Consol console2("Console 2");
	Consol console3("Console 3");

    Dashboard.Attach(&console1);
    Dashboard.Attach(&console2);
	Dashboard.Attach(&console3);

    //lets try changing the Dashboard price, this should update the Consoles automatically
    //Dashboard.ChangePrice("$126.112");

    //Now console2 is not interested in new prices so they unsubscribe
    //Dashboard.Detach(&console2);

    
	string Last_Price = "0";
	while (true)
	{
		string Updated_stock_Price = stock_price_display(stock_url, key, destFile);
		if (Last_Price != Updated_stock_Price)
		{
			Dashboard.ChangePrice(Updated_stock_Price);
			Last_Price = Updated_stock_Price;
		}
		Sleep(3000);
	}
}


void Get_the_url(const wchar_t*&stock_url, string &key, const wchar_t* &destFile)
{
    // Access it from DB or Some text file
    stock_url = L"https://query1.finance.yahoo.com/v7/finance/download/AAPL?";

	key = "Close";

	destFile = L"Apple.csv";
}

int main()
{
	
	string key;
    const wchar_t* stock_url;
	const wchar_t* destFile;
    Get_the_url(stock_url, key, destFile);

	//Initializing Dashboard and Consoles
	Initialize_Dashboard(stock_url, key, destFile);
    
    return 0;

}