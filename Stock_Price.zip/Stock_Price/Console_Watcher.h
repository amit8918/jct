#pragma once
#include <string>
using namespace std;

class Console_Watcher
{
public:
    virtual void Update(string stock_price) = 0;
};